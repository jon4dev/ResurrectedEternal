﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RRFull.BaseObjects
{
    class LightGlow
    {
//        |__m_clrRender_______________________________________ -> 0x0070 (int )
//|__m_nHorizontalSize_________________________________ -> 0x09D8 (int )
//|__m_nVerticalSize___________________________________ -> 0x09DC (int )
//|__m_nMinDist________________________________________ -> 0x09E0 (int )
//|__m_nMaxDist________________________________________ -> 0x09E4 (int )
//|__m_nOuterMaxDist___________________________________ -> 0x09E8 (int )
//|__m_spawnflags______________________________________ -> 0x09EC (int )
//|__m_vecOrigin_______________________________________ -> 0x0138 (Vec3 )
//|__m_angRotation_____________________________________ -> 0x012C (Vec3 )
//|__moveparent________________________________________ -> 0x0148 (int )
//|__m_flGlowProxySize_________________________________ -> 0x0AC4 (float )
//|__HDRColorScale_____________________________________ -> 0x0000 (float )
    }
}
