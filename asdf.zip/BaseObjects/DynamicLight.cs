﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RRFull.BaseObjects
{
    class DynamicLight
    {
//        DT_TEDynamicLight : public DT_BaseTempEntity
//|__m_vecOrigin_______________________________________ -> 0x0010 (Vec3 )
//|__r_________________________________________________ -> 0x0020 (int )
//|__g_________________________________________________ -> 0x0024 (int )
//|__b_________________________________________________ -> 0x0028 (int )
//|__exponent__________________________________________ -> 0x002C (int )
//|__m_fRadius_________________________________________ -> 0x001C (float )
//|__m_fTime___________________________________________ -> 0x0030 (float )
//|__m_fDecay__________________________________________ -> 0x0034 (float )
    }
}
