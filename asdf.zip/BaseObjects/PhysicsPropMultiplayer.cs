﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RRFull.BaseObjects
{
    class PhysicsPropMultiplayer : BaseEntity
    {
        public PhysicsPropMultiplayer(IntPtr addr, ClientClass _classid) : base(addr, _classid)
        {
        }
    }
}
