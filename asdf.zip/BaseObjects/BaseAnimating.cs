﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RRFull.BaseObjects
{
    class BaseAnimating
    {
//        DT_BaseAnimating : public DT_BaseEntity
//|__m_nSequence_______________________________________ -> 0x28BC (int )
//|__m_nForceBone______________________________________ -> 0x268C (int )
//|__m_vecForce________________________________________ -> 0x2680 (Vec3 )
//|__m_nSkin___________________________________________ -> 0x0A1C (int )
//|__m_nBody___________________________________________ -> 0x0A20 (int )
//|__m_nHitboxSet______________________________________ -> 0x09FC (int )
//|__m_flModelScale____________________________________ -> 0x2748 (float )
//|__m_flPoseParameter_________________________________ -> 0x2774 (void* )
// |__m_flPlaybackRate_________________________________ -> 0x0A18 (float )
// |__m_flEncodedController____________________________ -> 0x0A54 (void* )
//  |__m_bClientSideAnimation__________________________ -> 0x289C (int )
//  |__m_bClientSideFrameReset_________________________ -> 0x26C0 (int )
//  |__m_bClientSideRagdoll____________________________ -> 0x0279 (int )
//  |__m_nNewSequenceParity____________________________ -> 0x0A44 (int )
//  |__m_nResetEventsParity____________________________ -> 0x0A48 (int )
//  |__m_nMuzzleFlashParity____________________________ -> 0x0A64 (int )
//  |__m_hLightingOrigin_______________________________ -> 0x2944 (int )
//  |__serveranimdata__________________________________ -> 0x0000 (void* )
//   |__m_flCycle______________________________________ -> 0x0A14 (float )
//   |__m_flFrozen_____________________________________ -> 0x26F8 (float )
//   |__m_ScaleType____________________________________ -> 0x274C (int )
//   |__m_bSuppressAnimSounds__________________________ -> 0x294A (int )
//   |__m_nHighlightColorR_____________________________ -> 0x0A38 (int )
//   |__m_nHighlightColorG_____________________________ -> 0x0A3C (int )
//   |__m_nHighlightColorB_____________________________ -> 0x0A40 (int )
    }
}
