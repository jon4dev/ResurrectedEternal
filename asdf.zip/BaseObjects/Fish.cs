﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RRFull.BaseObjects
{
    class Fish
    {
//        |__m_poolOrigin______________________________________ -> 0x29E0 (Vec3 )
//|__m_x_______________________________________________ -> 0x29C8 (float )
//|__m_y_______________________________________________ -> 0x29CC (float )
//|__m_z_______________________________________________ -> 0x29D0 (float )
//|__m_angle___________________________________________ -> 0x29D8 (float )
//|__m_nModelIndex_____________________________________ -> 0x0258 (int )
//|__m_lifeState_______________________________________ -> 0x025F (int )
//|__m_waterLevel______________________________________ -> 0x29EC (float )
    }
}
