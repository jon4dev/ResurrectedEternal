﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace RRFull.Logging
//{
//    public static class ILog
//    {

//        private static string header = "#########################\n";
//        public static void AddToLog(string action, string text)
//        {
//            return;
//            System.IO.File.AppendAllText("writer.log.txt", "["+DateTime.Now + "]" + action + "\n" + text + "\n");
//        }

//    }
//}
