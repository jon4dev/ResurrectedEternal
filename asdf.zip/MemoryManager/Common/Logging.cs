﻿// Copyright (C) 2013-2015 aevitas
// See the file LICENSE for copying permission.

namespace RedRain.Common
{
	/// <summary>
	///     Handles all logging requirement for RedRain.
	/// </summary>
	internal static class Logging
	{
	}
}