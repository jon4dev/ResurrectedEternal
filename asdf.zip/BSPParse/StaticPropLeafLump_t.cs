﻿using System.Runtime.InteropServices;

namespace RRFull.BSPParse
{
    [StructLayout(LayoutKind.Sequential)]
    public struct StaticPropLeafLump_t
    {
        public int m_LeafEntries;
    }
}
